# 🔍 Google Search Query Anomaly Detection

A Google Colab-based project that detects anomalies in search trends using **Google Trends** data and **machine learning**.

## 🚀 Features

- Fetch search trend data using `pytrends`
- Visualize keyword trends with `matplotlib` and `seaborn`
- Detect anomalies using `Isolation Forest`
- Forecast trends and detect anomalies with `Prophet`
- Export results and plot interactive graphs

## 📊 Use Case

- SEO monitoring
- Trend detection
- Marketing insights
- Bot/spam search detection

## 🛠️ Technologies

- Python
- Google Colab
- pytrends
- prophet
- scikit-learn
- matplotlib
- seaborn

## 🧪 How to Run

### ➤ Open in Google Colab  
[Run on Colab](https://colab.research.google.com/drive/YOUR_NOTEBOOK_LINK)

### ➤ Manual Steps

1. Clone the repo:
```bash
git clone https://github.com/yourusername/google-search-query-anomaly-detector.git
```

2. Open the `notebook/anomaly_detection_google_trends.ipynb` in Colab

3. Run each cell and interact with the code

## 📷 Example Output

![Search Trends with Anomalies](images/result_plot.png)

## 📄 License

MIT License

## 👤 Author

[Your Name](https://www.linkedin.com/in/yourprofile)
